using Microsoft.EntityFrameworkCore;
using PetInfo.Clients;
using PetInfo.Models;
using Stripe;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.Configure<StripeSettings>(builder.Configuration.GetSection("StripeSettings"));
builder.Services.AddIdentity<AppUser, PetInfo.Models.Identity.AppRole>(options => options.SignIn.RequireConfirmedAccount = false)
                       .AddEntityFrameworkStores<PetDbContext>();
 builder.Services.AddDbContext<PetDbContext>(option =>
    option.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromSeconds(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddSingleton(x =>
    new PaypalClient(
        builder.Configuration["PayPalOptions:ClientId"],
        builder.Configuration["PayPalOptions:ClientSecret"],
        builder.Configuration["PayPalOptions:Mode"]
    )
);

builder.Services.AddCors();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowStripe", builder =>
    {
        builder.WithOrigins("https://js.stripe.com")
 ;
    });
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseSession();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseCors("AllowStripe");

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=AppUser}/{action=Register}/{id?}");

app.Run();
