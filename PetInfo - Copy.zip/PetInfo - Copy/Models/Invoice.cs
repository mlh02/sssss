﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace PetInfo.Models
{
    public class Invoice
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Company { get; set; }

        public int Price { get; set; }

        public DateTime InvoiceDate { get; set; } = DateTime.Now;

        public string RecipientEmail { get; set; }

        public bool IsPaid { get; set; } 

        // Img stuff
        [Column(TypeName = "nvarchar(100)")]
        public string ImageName { get; set; }

        [NotMapped]
        public IFormFile ImageFile { get; set; }

    }
}
