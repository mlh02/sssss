﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetInfo.Models
{
    public class Item
    {

        public Invoice Pet { get; set; }
        public int Quantity { get; set; }

    }
}
