﻿namespace PetInfo.Models
{
    public class StripeSettings
    {
        public string SecretKey { get; set; }
        public string PublishableKey { get; set; }
        public string Monthly { get; set; }
    }
}
