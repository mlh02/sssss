﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PetInfo.Models.Identity;
using System.Collections.Generic;

namespace PetInfo.Models
{
    public class PetDbContext : IdentityDbContext<AppUser, AppRole, int>
    {
        public PetDbContext(DbContextOptions<PetDbContext> options) : base(options)
        {

        }
        public DbSet<Invoice> Invoices { get; set; }
    }
}
