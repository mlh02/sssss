﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetInfo.Helpers.Enums
{
    public enum AppRoleEnum
    {
        User = 0,
        SuperUser = 1
    }
}
