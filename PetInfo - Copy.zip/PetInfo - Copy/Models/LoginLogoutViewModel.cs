﻿using PetInfo.Models.Identity;

namespace PetInfo.Models
{
    public class LoginLogoutViewModel
    {
        public AppLogin AppLogin { get; set; }
        public AppUser AppUser { get; set; }
    }
}
