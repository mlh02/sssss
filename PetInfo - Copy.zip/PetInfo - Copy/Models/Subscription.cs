﻿namespace PetInfo.Models
{
    public class Subscription
    {
        public int Id { get; set; }
        public string UserId { get; set; } // Relate to your user entity
        public string StripeSubscriptionId { get; set; }
    }
}
