﻿namespace PetInfo.Helper
{
    public static class IdentityRoleEnum
    {
        public static string AdminRole { get; set; } = "Admin";
        public static string UserRole { get; set; } = "User";
    }
}
