﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetInfo.Models;
using PetInfo.Models.Identity;

namespace PetInfo.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly PetDbContext _context;
        private readonly IWebHostEnvironment _hostEnvironment;

		private SignInManager<AppUser> _signInManager; // Manages your login, logout, getting users based on properties like name and Id
		private RoleManager<AppRole> _roleManager; // This manages roles, like assinging, creating new roles, or removing roles etc
		private UserManager<AppUser> _userManger; // Register users and validation

		public InvoiceController(PetDbContext context, IWebHostEnvironment hostEnvironment, SignInManager<AppUser> signInManager,
			RoleManager<AppRole> roleManager, UserManager<AppUser> userManger)
        {
            _context = context;
            this._hostEnvironment = hostEnvironment;
			_userManger = userManger;
			_signInManager = signInManager;
			_roleManager = roleManager;
		}
		public AppUser GetCurrentUser()
		{
			var userID = _userManger.GetUserId(HttpContext.User);
			var user = _userManger.FindByIdAsync(userID).Result;
			return user;
		}
		// GET: Pets
		public async Task<IActionResult> Index()
        {
            var currUser = GetCurrentUser();
           
			if (currUser.IsAdmin)
            {
				return View(await _context.Invoices.ToListAsync());
			}
            else
            {
				return View(await _context.Invoices.Where(x => x.RecipientEmail == currUser.Email).ToListAsync());
			}
		}

        // GET: Pets/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pet = await _context.Invoices
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pet == null)
            {
                return NotFound();
            }

            return View(pet);
        }

        // GET: Pets/Create
        public IActionResult AddOrEdit(int Id = 0)
        {
            ViewBag.Recipients = _context.Invoices.Select(x => x.RecipientEmail).Distinct().ToList();
            ViewBag.Count = ViewBag.Recipients.Count ;
            if (Id == 0)
                return View(new Invoice());
            else
                return View(_context.Invoices.Find(Id));
        }

        // POST: Pets/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit( Invoice pet)
        {
            if (ModelState.IsValid)
            {
                if (pet.Id == 0)
                {

                    //Save image to wwwroot/image
                    string wwwRootPath = _hostEnvironment.WebRootPath;
                    string fileName = Path.GetFileNameWithoutExtension(pet.ImageFile.FileName);
                    string extension = Path.GetExtension(pet.ImageFile.FileName);
                    pet.ImageName = fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                    string path = Path.Combine(wwwRootPath + "/Image/", fileName);
                    using (var fileStream = new FileStream(path, FileMode.Create))
                    {
                        await pet.ImageFile.CopyToAsync(fileStream);
                    }
                    _context.Add(pet);
                }
                else
                {
                    _context.Update(pet);

                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pet);
        }

        // GET: Pets/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pet = await _context.Invoices.FindAsync(id);
            if (pet == null)
            {
                return NotFound();
            }
            return View(pet);
        }

        // POST: Pets/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PetId,PetName,PetOwnerName,PetAddress,ImageName,ImageFile")] Invoice pet)
        {
            if (id != pet.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PetExists(pet.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pet);
        }

        // GET: Pets/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pet = await _context.Invoices
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pet == null)
            {
                return NotFound();
            }

            return View(pet);
        }

        // POST: Pets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pet = await _context.Invoices.FindAsync(id);
            _context.Invoices.Remove(pet);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PetExists(int id)
        {
            return _context.Invoices.Any(e => e.Id == id);
        }
    }
}
