﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PetInfo.Models;
using Stripe.Checkout;
using Stripe;
using PetInfo.Helper;

namespace PetInfo.Controllers
{
    public class StripeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly StripeSettings _stripeSettings;
        public string SessionId { get; set; }


        public StripeController(ILogger<HomeController> logger, IOptions<StripeSettings> stripeSetting)
        {
            _logger = logger;
            _stripeSettings = stripeSetting.Value;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Success()
        {
            return View();
        }
         
        public IActionResult Cancel()
        {
            return View();
        }
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Subscribe(string email, string plan, string stripeToken)
        //{
        //    StripeConfiguration.ApiKey = _stripeSettings.SecretKey;

        //    var customerOptions = new CustomerCreateOptions
        //    {
        //        Email = email,
        //        Source = stripeToken,
        //        //Plan = plan,
        //    };

        //    var customerService = new CustomerService();
        //    var customer = customerService.Create(customerOptions);

        //    return View("SubscribeResult");
        //}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Subscribe(string email, string plan, string stripeToken)
        {
            // Previous code in action
              StripeConfiguration.ApiKey = _stripeSettings.SecretKey;

            var planId = _stripeSettings.Monthly;
            var customerOptions = new CustomerCreateOptions
            {
                Email = email,
                Source = stripeToken,
            };

            var customerService = new CustomerService();
            var customer = customerService.Create(customerOptions);


            var subscriptionOptions = new SubscriptionCreateOptions
            {
                Customer = customer.Id,
                Items = new List<SubscriptionItemOptions>
            {
            new SubscriptionItemOptions
            {
                Plan = planId
            },
        },
            };
            subscriptionOptions.AddExpand("latest_invoice.payment_intent");

            var subscriptionService = new SubscriptionService();
            var subscription = subscriptionService.Create(subscriptionOptions);

            ViewBag.stripeKey = _stripeSettings.PublishableKey ;
            ViewBag.subscription = subscription.ToJson();

            return View("SubscribeResult");
        }
        [HttpGet]
        public IActionResult Subscribe()
        {
            ViewBag.stripeKey = _stripeSettings.PublishableKey;
            return View();
        }
        [HttpPost]
        public IActionResult CreateCheckoutSession( )
        {
            // Calculate the total amount (price * quantity)
            var cart = SessionHelper.GetObjectFromJson<List<Item>>(HttpContext.Session, "cart");
            ViewBag.cart = cart;
            ViewBag.DollarAmount = cart.Sum(item => item.Pet.Price * item.Quantity);
            ViewBag.total = ViewBag.DollarAmount;
            int total = ViewBag.total;
            StripeConfiguration.ApiKey = _stripeSettings.SecretKey;

            // Create a PaymentIntent using Stripe API
            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string>
                {
                    "card"
                },
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            Currency = "usd",
                            UnitAmount = total * 100,
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = "Product Test 1",
                                Description = "Description Test 1"
                            }
                        },
                        Quantity = 1
                    }
                },
                Mode = "payment",
                SuccessUrl = "https://localhost:44385/Stripe/Success",
                CancelUrl = "https://localhost:44385/Stripe/Cancel"
            };
            //options.LineItems.FirstOrDefault().Price =  "";
            var service = new SessionService();
            var session = service.Create(options);
            SessionId = session.Id;
            return Redirect(session.Url);
        }
        //-------------------------------

        [HttpPost]
        public ActionResult CreateCheckoutSessionSubscription()
        {
            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string> { "card", },
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        Price = "your_price_id_here", // Replace with your price ID
                        Quantity = 1,
                    },
                },
                Mode = "subscription",
                SuccessUrl = "https://example.com/success",
                CancelUrl = "https://example.com/cancel",
            };

            var service = new SessionService();
            Session session = service.Create(options);

            return Json(new { id = session.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Webhook()
        {
            var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync();

            try
            {
                var stripeEvent = EventUtility.ConstructEvent(
                    json,
                    Request.Headers["Stripes-Signature"],
                    "whsec_vRD0hu1A9NM1k90NAfoSml9rN7JHyBAN"
                );

                // Handle the checkout.session.completed event
                if (stripeEvent.Type == Events.CheckoutSessionCompleted)
                {
                    var session = stripeEvent.Data.Object as Session;
                    // TODO: Handle successful checkout, e.g., save subscription
                }

                return Ok();
            }
            catch (StripeException e)
            {
                return BadRequest();
            }
        }

    }
}
